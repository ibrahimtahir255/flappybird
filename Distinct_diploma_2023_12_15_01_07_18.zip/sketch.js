let bird;
let pipes = [];
let score = 0;
let bgColor;

function setup() {
  createCanvas(400, 600);
  bird = new Bird();
  pipes.push(new Pipe());
  bgColor = color(220);
}

function draw() {
  background(bgColor);

  bird.update();
  bird.show();

  if (frameCount % 100 == 0) {
    pipes.push(new Pipe());
  }

  for (let i = pipes.length - 1; i >= 0; i--) {
    pipes[i].update();
    pipes[i].show();

    if (pipes[i].hits(bird)) {
      console.log('Game over!');
      pipes = [];
      score = 0;
      bgColor = color(220);
    }

    // Check if the pipe is offscreen before updating and showing
    if (pipes[i] && pipes[i].offscreen()) {
      if (!pipes[i].scored) {
        score++;
        pipes[i].scored = true; // Mark the pipe as scored
        bgColor = color(random(255), random(255), random(255));
      }
    }
  }

  // Remove offscreen pipes
  pipes = pipes.filter(pipe => !pipe.offscreen());

  showScore();
}

function keyPressed() {
  if (keyCode === UP_ARROW) {
    bird.up();
  }
}

function mousePressed() {
  bird.up();
}

function showScore() {
  fill(0);
  textSize(32);
  text('Score: ' + score, 10, 30);
}

class Bird {
  constructor() {
    this.y = height / 2;
    this.x = 64;
    this.gravity = 0.6;
    this.lift = -15;
    this.velocity = 0;
  }

  show() {
    fill(255);
    ellipse(this.x, this.y, 32, 32);
  }

  update() {
    this.velocity += this.gravity;
    this.velocity *= 0.9;
    this.y += this.velocity;

    if (this.y > height) {
      this.y = height;
      this.velocity = 0;
    }

    if (this.y < 0) {
      this.y = 0;
      this.velocity = 0;
    }
  }

  up() {
    this.velocity += this.lift;
  }
}

class Pipe {
  constructor() {
    this.spacing = 125;
    this.top = random(height / 4, height / 2 - this.spacing);
    this.bottom = height - (this.top + this.spacing);
    this.x = width;
    this.w = 30;
    this.speed = 2;
    this.scored = false;
  }

  show() {
    fill(0, 200, 0);
    rect(this.x, 0, this.w, this.top);
    rect(this.x, height - this.bottom, this.w, this.bottom);
  }

  update() {
    this.x -= this.speed;
  }

  offscreen() {
    return this.x < -this.w;
  }

  hits(bird) {
    return (
      bird.x > this.x &&
      bird.x < this.x + this.w &&
      (bird.y < this.top || bird.y > height - this.bottom)
    );
  }
}
